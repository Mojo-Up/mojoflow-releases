// MojoFlow's window on the desktop, for GNOME on Wayland.
//
// Wayland does not let an app ask which window is in front, what is running, or which screen
// the person is working on; GNOME Shell knows all three. This extension answers those questions
// over the session bus (au.com.mojoup.MojoFlow.Shell) so MojoFlow can apply per-app clean-up
// rules and put its status pill on the right screen.
//
// It answers MojoFlow and nothing else: every call checks that the caller's executable is
// named `mojoflow`, because a window title can be private and any program on the session bus
// could otherwise ask for it. It keeps no state and draws nothing.

import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Shell from 'gi://Shell';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';

const BUS_NAME = 'au.com.mojoup.MojoFlow.Shell';
const OBJECT_PATH = '/au/com/mojoup/MojoFlow/Shell';

// Version 1. Add methods rather than change these; MojoFlow checks the Version property.
const INTERFACE = `
<node>
  <interface name="au.com.mojoup.MojoFlow.Shell1">
    <property name="Version" type="u" access="read"/>
    <method name="FocusedWindow">
      <arg type="s" direction="out" name="wmClass"/>
      <arg type="s" direction="out" name="appId"/>
      <arg type="s" direction="out" name="title"/>
      <arg type="i" direction="out" name="monitor"/>
    </method>
    <method name="RunningApps">
      <arg type="a(ss)" direction="out" name="apps"/>
    </method>
  </interface>
</node>`;

export default class MojoFlowExtension extends Extension {
    enable() {
        this._service = new MojoFlowService();
        this._exported = Gio.DBusExportedObject.wrapJSObject(INTERFACE, this._service);
        this._exported.export(Gio.DBus.session, OBJECT_PATH);
        this._nameId = Gio.bus_own_name_on_connection(Gio.DBus.session, BUS_NAME, Gio.BusNameOwnerFlags.REPLACE, null, null);
    }

    disable() {
        if (this._nameId) {
            Gio.bus_unown_name(this._nameId);
            this._nameId = 0;
        }

        this._exported?.unexport();
        this._exported = null;
        this._service = null;
    }
}

class MojoFlowService {
    get Version() {
        return 1;
    }

    FocusedWindowAsync(params, invocation) {
        answer(invocation, () => {
            const window = global.display.focus_window;
            if (!window)
                return new GLib.Variant('(sssi)', ['', '', '', -1]);

            const app = Shell.WindowTracker.get_default().get_window_app(window);
            return new GLib.Variant('(sssi)', [
                window.get_wm_class() ?? '',
                app?.get_id() ?? '',
                window.get_title() ?? '',
                window.get_monitor(),
            ]);
        });
    }

    RunningAppsAsync(params, invocation) {
        answer(invocation, () => {
            const apps = [];
            const seen = new Set();
            for (const actor of global.get_window_actors()) {
                const window = actor.meta_window;
                if (window.skip_taskbar)
                    continue;

                const wmClass = window.get_wm_class() ?? '';
                if (!wmClass || seen.has(wmClass.toLowerCase()))
                    continue;

                seen.add(wmClass.toLowerCase());
                apps.push([wmClass, window.get_title() ?? '']);
            }

            return new GLib.Variant('(a(ss))', [apps]);
        });
    }
}

/** Runs `reply` for MojoFlow; refuses everyone else. */
function answer(invocation, reply) {
    if (!callerIsMojoFlow(invocation.get_sender())) {
        invocation.return_dbus_error('org.freedesktop.DBus.Error.AccessDenied', 'This service answers MojoFlow only');
        return;
    }

    try {
        invocation.return_value(reply());
    } catch (e) {
        invocation.return_dbus_error('org.freedesktop.DBus.Error.Failed', `${e}`);
    }
}

function callerIsMojoFlow(sender) {
    try {
        const [pid] = Gio.DBus.session.call_sync(
            'org.freedesktop.DBus', '/org/freedesktop/DBus', 'org.freedesktop.DBus',
            'GetConnectionUnixProcessID', new GLib.Variant('(s)', [sender]),
            new GLib.VariantType('(u)'), Gio.DBusCallFlags.NONE, 500, null).deep_unpack();
        const exe = GLib.file_read_link(`/proc/${pid}/exe`);
        return GLib.path_get_basename(exe) === 'mojoflow';
    } catch (e) {
        return false;
    }
}
